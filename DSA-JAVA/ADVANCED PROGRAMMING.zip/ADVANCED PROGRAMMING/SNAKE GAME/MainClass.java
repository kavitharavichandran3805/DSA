public class MainClass {
    public static void main(String[] args) {
        Snake obj = new Snake(6, 6);
        obj.startGame();
    }
}